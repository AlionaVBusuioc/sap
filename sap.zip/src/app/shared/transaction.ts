export class Transaction {
  id: number;
  date: any;
  credit: number;
  debit: number;
}

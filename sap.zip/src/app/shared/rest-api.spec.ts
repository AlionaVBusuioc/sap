import { RestApi } from './rest-api';

describe('RestApi', () => {
  it('should create an instance', () => {
    expect(new RestApi()).toBeTruthy();
  });
});

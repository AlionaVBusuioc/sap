import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Transaction } from '../shared/transaction';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class RestApiService {
// Define API
apiURL = 'http://localhost:3000';
  constructor(private http: HttpClient) { }
  /*========================================
  CRUD Methods for consuming RESTful API
  =========================================*/
  // Http Options
  httpOptions = {
    headers: new HttpHeaders({
    'Content-Type': 'application/json'
    })
    }  
    // HttpClient API get() method => Fetch transactions list
    getTransactions(): Observable<Transaction> {
    return this.http.get<Transaction>(this.apiURL + '/transactions')
    .pipe(
    retry(1),
    catchError(this.handleError)
    )
    }
    // HttpClient API get() method => Fetch transaction
    getTransaction(id): Observable<Transaction> {
    return this.http.get<Transaction>(this.apiURL + '/transactions/' + id)
    .pipe(
    retry(1),
    catchError(this.handleError)
    )
    }  
    // HttpClient API post() method => Create transaction
    createTransaction(transaction): Observable<Transaction> {
    return this.http.post<Transaction>(this.apiURL + '/transactions', JSON.stringify(transaction), this.httpOptions)
    .pipe(
    retry(1),
    catchError(this.handleError)
    )
    }  
    // HttpClient API put() method => Update transaction
    updateTransaction(id, transaction): Observable<Transaction> {
    return this.http.put<Transaction>(this.apiURL + '/transactions/' + id, JSON.stringify(transaction), this.httpOptions)
    .pipe(
    retry(1),
    catchError(this.handleError)
    )
    }
    // HttpClient API delete() method => Delete transaction
    deleteTransaction(id){
    return this.http.delete<Transaction>(this.apiURL + '/transactions/' + id, this.httpOptions)
    .pipe(
    retry(1),
    catchError(this.handleError)
    )
    }
    // Error handling 
    handleError(error) {
    let errorMessage = '';
    if(error.error instanceof ErrorEvent) {
    // Get client-side error
    errorMessage = error.error.message;
    } else {
    // Get server-side error
    errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    window.alert(errorMessage);
    return throwError(errorMessage);
    }
}

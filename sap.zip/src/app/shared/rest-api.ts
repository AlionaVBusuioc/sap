export class RestApi {
}

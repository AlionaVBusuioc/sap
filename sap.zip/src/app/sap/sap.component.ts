import { Component, OnInit, ViewChild } from '@angular/core';
import {MatTableDataSource, MatSort, MatPaginator} from '@angular/material';
import {MatDialog, MatDialogConfig} from '@angular/material';
import { CreateTransactionComponent } from '../create-transaction/create-transaction.component';
import { RestApiService } from "../shared/rest-api.service";
import { Data } from '@angular/router';
export interface PeriodicElement {
  date: any;
  id: number;
  credit: number;
  debit: number;
}
const ELEMENT_DATA: PeriodicElement[] = [
  {id: 1, date: '10/1/2019', debit: 10000, credit: 1000},
  {id: 2, date: '10/2/2019', debit: 15000, credit: 0},
  {id: 3, date: '10/3/2019', debit: 0, credit: 1000},
  {id: 4, date: '10/4/2019', debit: 25000, credit: 0},
  {id: 5, date: '10/5/2019', debit: 0, credit: 5000},
  {id: 6, date: '10/6/2019', debit: 0, credit: 5000},
  {id: 7, date: '10/7/2019', debit: 20000, credit: 0},
  {id: 8, date: '10/8/2019', debit: 24000, credit: 5000},
  {id: 9, date: '10/9/2019', debit: 11000, credit: 0},
  {id: 10, date: '10/10/2019', debit: 30000, credit: 4000},
  {id: 11, date: '10/11/2019', debit: 7000, credit: 0},
  {id: 12, date: '10/12/2019', debit: 0, credit: 1500},
  {id: 13, date: '10/13/2019', debit: 4000, credit: 3000},
  {id: 14, date: '10/14/2019', debit: 21000, credit: 0},
  {id: 15, date: '10/15/2019', debit: 15000, credit: 0},
];

@Component({
  selector: 'app-sap',
  templateUrl: './sap.component.html',
  styleUrls: ['./sap.component.css']
})
export class SapComponent implements OnInit { 
  displayedColumns: string[] = ['id', 'date', 'debit', 'credit', 'remove'];
  dataSource = new MatTableDataSource(ELEMENT_DATA);

  @ViewChild(MatSort, {static: true}) sort: MatSort;
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  
  Transaction: any = [];
  constructor( private dialog: MatDialog,
    public restApi: RestApiService
    ) { }

  ngOnInit()
  {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
    this.loadTransactions()
  }
  loadTransactions() {
    return this.restApi.getTransactions().subscribe((data: {}) => {
    this.Transaction = data;
    })
    }
    deleteTransaction(id) {
      if (window.confirm('Do you really want to delete transaction?')){
      this.restApi.deleteTransaction(id).subscribe(data => {
      this.loadTransactions()
      })
      }
      } 
  applyFilter(filterValue: string){
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
  onCreate(){
    /* this.service.initializeFormGroup(); */
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true; //for closing the popup window
   this.dialog.open(CreateTransactionComponent);
  }
}



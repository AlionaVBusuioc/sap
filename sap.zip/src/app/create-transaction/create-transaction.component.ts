import { Component, OnInit, Input } from '@angular/core';
import {MatDialogRef} from '@angular/material';
import { Router } from '@angular/router';
import { RestApiService } from "../shared/rest-api.service";
import { SapComponent } from '../sap/sap.component';
import { Transaction } from '../shared/transaction';

@Component({
  selector: 'app-create-transaction',
  templateUrl: './create-transaction.component.html',
  styleUrls: ['./create-transaction.component.css']
})
export class CreateTransactionComponent implements OnInit {
  @Input() transactionDetails = {id: '', date: '', debit: '', credit: ''}
  constructor(
  public restApi: RestApiService, 
  public router: Router,
  public dialogRef: MatDialogRef<SapComponent>
  ) { }

  ngOnInit() { }
  addTransaction(dataTransaction) {
  this.restApi.createTransaction(this.transactionDetails).subscribe((data: {}) => {
  this.router.navigate(['/transaction'])
  })
  }
  close(){
    this.dialogRef.close();
  }
  }


import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PieComponent } from './pie/pie.component';
import { SapComponent } from './sap/sap.component';
import { CreateTransactionComponent } from './create-transaction/create-transaction.component';


const routes: Routes = [{ path: '', redirectTo: '/sap', pathMatch: 'full' },
{ path: 'pie', component: PieComponent },
{ path: 'sap', component: SapComponent },
{ path: 'transaction', component: CreateTransactionComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
